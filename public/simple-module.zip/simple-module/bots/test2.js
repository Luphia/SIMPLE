var ParentBot = require('./_SocketBot.js')
,	util = require('util')
,	Result = require('../classes/Result.js');


var Bot = function (config) {
    if (!config) config = {};
    this.init(config);
};

util.inherits(Bot, ParentBot);

Bot.prototype.init = function (config) {
    Bot.super_.prototype.init.call(this, config);
    this.path = "/test/:no";
};

Bot.prototype.start = function () {
    Bot.super_.prototype.start.apply(this);
};

Bot.prototype.stop = function () {
    Bot.super_.prototype.stop.apply(this);
};

Bot.prototype.exec = function (msg) {
	var rs = new Result();
	rs.setData(msg);
	return rs;
};

module.exports = Bot;