var ParentBot = require('./_SocketBot.js')
, util = require('util');

var Bot = function (config) {
    if (!config) config = {};
    this.init(config);
};

util.inherits(Bot, ParentBot);

Bot.prototype.init = function (config) {
    Bot.super_.prototype.init.call(this, config);
    //this.path = "/kitchen/:KitchenId";
    //this.path = {"method": "get", "path": "/kitchen/:KitchenId"};
    this.path = [{"method": "get", "path": "/test"}];
};

Bot.prototype.exec = function (msg) {
	var rs = this.ask(msg, "test2");
	//var sql = "select * from ?";
	//var param = ["useraccount"];
	//rs = this.query(sql);
	//rs = this.query(sql, param);
	return rs;
};

module.exports = Bot;