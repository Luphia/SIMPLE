var fs = require('fs')
,	sub = 'js'
,	reg = new RegExp('\.' + sub + '$')
,	folder = __dirname + "/bots/"
,	files = fs.readdirSync(folder)
;

var botList = {};
for(var key in files) {
	if(reg.test(files[key]) && files[key].indexOf("_") == -1) {
		var nameArr = files[key].split(".");
		nameArr.pop();
		var name = nameArr.join(".");
		botList[name] = require(folder + files[key]);
	}
}

module.exports = {
	bots: botList,
	public: __dirname + "/public/"
};