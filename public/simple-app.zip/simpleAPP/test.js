#!/usr/bin/env node

var Receptor = require('./Receptor.js');
var receptor = new Receptor();
var simple = require('./index.js');

for(var k in simple.bots) {
	var bot = new simple.bots[k]();
	bot.name = k;
	receptor.addController(bot);
}

receptor.start();

